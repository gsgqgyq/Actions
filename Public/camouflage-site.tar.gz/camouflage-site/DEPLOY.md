# 星辰云盘伪装站 - Caddy 部署配置
# 
# 将此配置合并到你现有的 Caddyfile 中：
#   1. 上传 camouflage-site 目录到 VPS: /var/www/camouflage
#   2. 在 Caddyfile 的 site block 中：
#       handle /camouflage/* { ... 你的代理逻辑 ... }
#       handle { root * /var/www/camouflage file_server }
#
# 逻辑：普通浏览器访问 → 显示伪装云盘站，代理协议访问 → 走代理通道

# === 方式一：在你的 Caddyfile 中追加 ===
# 假设你现有:
#   your.domain.com {
#       @proxy expression {header.X-Proxy} == "true"
#       reverse_proxy @proxy ...
#       root * /var/www/camouflage
#       file_server
#   }

# === 方式二：独立部署（测试用）===
# 上传后本地测试：
#   cd /var/www/camouflage && python3 -m http.server 8080
#   或者直接 Caddy: caddy file-server --root /var/www/camouflage

# === 上传到 VPS ===
# rsync -avz --delete ./camouflage-site/ root@你的VPS:/var/www/camouflage/
